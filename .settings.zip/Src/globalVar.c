/*
 * GlobalVar.c
 *
 *  Created on: ? �? ???? �.�.
 *      Author: pr
 */
#include "stm32f1xx_hal.h"


SPI_HandleTypeDef hspi2;

//TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
